from bar_tab import Tab
Table1 = Tab()
# print(Table1)
Table1.add('soft_drink')
Table1.add('chicken')
Table1.add('desert')
print(Table1.print_bill(10, 10))
