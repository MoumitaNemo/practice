# from basic import Personality  # from <filename> import <classname>
from space.calc import planet_mass, planet_vol
from space.planet import Personality  # folder.file
Sky = Personality('Sky', 26, 'Art', 'Artist', 3455, 678)
# print(f'Name:{Sky.name}')
# print(Sky.spin('a very high speed'))


Sky_mass = planet_mass(Sky.gravity, Sky.radius)
Sky_vol = planet_vol(Sky.radius)
