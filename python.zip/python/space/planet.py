class Personality:  # starts capital
    shape = "round"  # class level attribute can call any where :INSTANCE + CLASS

    # define init function,new obj of this class
    def __init__(self, name, age, work, tech, radius, gravity):
        self.name = name  # instance attribute because diff from each instance
        self.age = age
        self.work = work
        self.tech = tech
        self.radius = radius
        self.gravity = gravity

    def own(self):
        return f'{self.name} is in {self.tech} team'

    @classmethod  # decorator -commmon for all
    def commons(cls):  # access to class level attribute
        return f'all shapes are {cls.shape}'

    # static method is kind of decorators which doesn't have access to self or class level attribute.Only access to the parameter which are passing through it individually.
    @staticmethod
    def spin(speed='2000 miles per hr'):
        return f'spins speed is {speed}'


#person = Personality('Mou', 24, 'IT', 'automation', 678, 980)
# print(f'Name is:{person.name}')
# print(f'age is:{person.age}')
# print(person.own())
#Sky = Personality('Sky', 26, 'Art', 'Artist', 4567, 478)
# print(f'Name :{Sky.name}')
# print(f'Age:{Sky.age}')
# print(f'Work:{Sky.work}')
# print(f'Tech:{Sky.tech}')
# print(Sky.own())
# print(Personality.shape)
# print(Personality.commons())
# print(Sky.commons())
# print(Personality.spin())
# print(Sky.spin('a very high speed'))
