<?php
if(isset($_POST['name'])){
$server = "localhost";
$username = "root";
$password = "";

$con = mysqli_connect($server,$username,$password);
if(!$con){
    die('connection to this databse failed due to'.$mysqli_connect_error());

}

echo "successful connection";



if($con->query($sql) == true){     #object operator
    echo "successfully inserted";
}
else{
    echo "ERROR:$sql <br> $con->error";
}
$con->close();

}
?> 