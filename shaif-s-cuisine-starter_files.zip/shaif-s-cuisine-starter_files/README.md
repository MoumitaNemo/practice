# Shaif's Cuisine

**A HTML CSS Project**. Mede with ♥ by web cifar community <br>
live Preview: [Click Me](http://shaif-s-cuisine.netlify.app)

![](./readmeImg/banner.png)

## Developer teams of Shaif's Cuisine

1. Shaif Arfan
1. Anwar saeed
1. MD Moniruzzaman Sojol
1. Lovekesh Pal
1. Houmayan Rashid Chy
